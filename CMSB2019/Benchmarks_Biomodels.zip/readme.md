Data: Biomodels Database
Snapshot: 26 July 2017

Description: Reduction in the number of species and reactions on biological models from Biomodels Database.
			 All experiments were performed using ERODE, a software tool for the solution and exact reduction of systems of ordinary differential equations (ODEs)
			 Software: https://sysma.imtlucca.it/tools/erode/

Folder ERODE: ERODE specifications of each of the models tested.
	          Note: We kept the biomodel Id for each model for easy identification; curated models start 	with the prefix "BIOMD", while non curated models start with the prefix "MODEL".

Folder Reductions: Reduced models obtained with BDE,FDE,FE,BE,SMB.




